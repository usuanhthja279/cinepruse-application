import csv
import sys
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from district_extractor import extract_snapshot, make_url, parse_movie_url, slugify_city

BASE = Path(__file__).resolve().parents[1]

class ExtractorTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.snapshot = extract_snapshot((BASE / 'fixtures/ramayana_kolkata_2026-11-06.html').read_text(encoding='utf-8'),
                                        source_city='kolkata', expected_movie_id='176276')

    def test_counts(self):
        m = self.snapshot['metadata']
        self.assertEqual(m['movie_id'], '176276')
        self.assertEqual(m['cinemas_with_shows'], 29)
        self.assertEqual(m['shows'], 117)
        self.assertEqual(m['seat_categories'], 410)
        self.assertEqual(m['total_seats_across_shows'], 27663)
        self.assertEqual(m['available_seats_across_shows'], 20461)
        self.assertEqual(m['unavailable_pct'], 26.03)

    def test_acropolis_first_session(self):
        shows = [x for x in self.snapshot['shows'] if x['cinema_id'] == 148 and x['show_time_ist'] == '21:45']
        self.assertTrue(shows)
        row = shows[0]
        self.assertEqual(row['total_seats'], 252)
        self.assertEqual(row['available_seats'], 86)
        self.assertEqual(row['screen_format'], '3D')
        areas = [x for x in self.snapshot['areas'] if x['session_key'] == row['session_key']]
        self.assertEqual([x['category_label'] for x in areas], ['NORMAL','EXECUTIVE','PREMIUM'])
        self.assertEqual([x['available_seats'] for x in areas], [21,51,14])

    def test_url(self):
        url = make_url('Ramayana', '176276', 'Delhi', '2026-11-07', 'rtb7dmwvuo')
        self.assertEqual(url, 'https://www.district.in/movies/ramayana-movie-tickets-in-delhi-ncr-MV176276?frmtid=rtb7dmwvuo&fromdate=2026-11-07')
        self.assertEqual(parse_movie_url(url)['city'], 'delhi-ncr')
        self.assertEqual(slugify_city('Visakhapatnam'), 'vizag')

    def test_500_candidate_uniq(self):
        with (BASE / 'cities_500_candidates.csv').open(encoding='utf-8-sig') as f:
            rows=list(csv.DictReader(f))
        self.assertEqual(len(rows), 500)
        self.assertEqual(len({r['slug'] for r in rows}),500)
        self.assertEqual(rows[0]['slug'],'mumbai')

if __name__ == '__main__': unittest.main()
