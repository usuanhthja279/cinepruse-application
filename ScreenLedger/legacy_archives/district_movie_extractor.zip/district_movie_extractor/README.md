# District movie HTML extractor (Python)

**Status:** Tested against the **user-supplied November 6, 2026 Ramayana/Kolkata HTML**. This is an HTML/Next.js JSON parser, not a seat booking tool. The test does **not** verify that live District requests from your machine will be allowed.

## Install (Windows PowerShell)

```powershell
cd district_movie_extractor
py -3 -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

## Step 1: Repeat the offline test (requires no internet)

```powershell
python district_extractor.py --html fixtures/ramayana_kolkata_2026-11-06.html --city kolkata --out output
python -m unittest discover -s tests -v
```

Expected from the supplied HTML: **29 cinemas, 117 shows, 410 category records**. Total seats across these shows: 27,663; available: 20,461; unavailable: 7,202 (26.03%). **Unavailable seats must not be represented as ticket sales.**

## Step 2: Movie/city URLs

Movie ID `176276`, movie slug `ramayana` and city slug can vary:

- `https://www.district.in/movies/ramayana-movie-tickets-in-kolkata-MV176276`
- `https://www.district.in/movies/ramayana-movie-tickets-in-mumbai-MV176276`
- `https://www.district.in/movies/ramayana-movie-tickets-in-delhi-ncr-MV176276`
- `https://www.district.in/movies/ramayana-movie-tickets-in-jaipur-MV176276`

**Access restriction:** District's Terms of Service restrict scraping/crawling, so do not run a live automated collector without authorization. The fetch switch requires an affirmative `--acknowledge-permission`; it is not evidence permission has been obtained. The program makes ordinary HTML GETs only, does not use proxies or bypass challenges, and stops on HTTP 403/429.

Once authorized, example single-city live commands:

```powershell
python district_extractor.py --fetch --acknowledge-permission --movie-id 176276 --movie-slug ramayana --city mumbai --out output_mumbai
python district_extractor.py --fetch --acknowledge-permission --url 'https://www.district.in/movies/ramayana-movie-tickets-in-jaipur-MV176276' --out output_jaipur
python district_extractor.py --fetch --acknowledge-permission --city kolkata --date 2026-11-07 --format-id rtb7dmwvuo --out output_nov7
```

Dates use `fromdate=YYYY-MM-DD` and, where supplied, `frmtid`. The format group is specific to a movie/language; a different film may need a different `frmtid` (which is discoverable in its loaded JSON). The HTML parser accepts multiple format groups.

## Step 3: 500 candidate locations

`cities_500_candidates.csv` contains 500 **heuristically prioritized Indian locations**, with major cities first and other regions balanced in. It is **not a verified District-supported list**, and the ranking is **not by actual District show count**. `district_evidence` distinguishes four checked Ramayana city URLs from mentions on District's movies landing page and unverified suggestions.

To regenerate:

```powershell
python build_city_candidates.py --count 500 --out cities_500_candidates.csv
```

For a better population-based candidate list you can optionally supply a [GeoNames](https://download.geonames.org/export/dump/cities15000.zip) dataset:

```powershell
python build_city_candidates.py --count 500 --geonames cities15000.zip --out cities_500_candidates.csv
```

Note: handcrafted candidates are always prioritized first; GeoNames fills gaps when necessary. Population and District activity are different metrics.

If you have authorization to perform multiple-city requests, use a **very small test first** (never start with 500 unverified URLs):

```powershell
python district_extractor.py --fetch --acknowledge-permission --cities-file cities_500_candidates.csv --max-cities 2 --delay 10 --out output_two_cities
```

### Do not claim 99% show coverage yet

To establish that the top 500 account for 99% of District shows, first obtain authorized show counts for the entire District city roster over the same time window, **deduplicate the same cinema/show session appearing in multiple city feeds**, rank cities by incremental unique show contribution, and calculate:

`coverage = unique_session_count_in_selected_500 / unique_session_count_across_all_supported_cities`

No such census is included. One film's show count cannot establish a 99% figure for **all films**.

## Output files

- `shows.csv`: flat rows: cinema, start time in IST, screen format, seats, min/max price, session IDs and booking URL
- `seat_categories.csv`: seating-area price and seats for each show
- `city_results.csv`: city summary to compare coverage
- `metadata.json`: movie, requested city, page-resolved city, counts, advertised dates
- `snapshots.json`: full normalized structured output
- `errors.json`: produced if a requested city fetch failed

The scraper never purchases tickets or calls the booking API. Extracted seat counts can reflect unavailable inventory, temporary holds and non-sale blocks; prices shown are area prices and may exclude fees.

## Limitations

- Not all city slugs are the same as their common names (`delhi-ncr`, `vizag`, `trivandrum`). Validate each city against District and update aliases.
- On some movie URLs, the site may use a different slug, return no showtimes, or redirect; `actual_city` helps detect misrouting.
- The raw `showTime` in the supplied Next.js payload appears UTC without a timezone suffix. We interpret such timestamps as UTC and convert to Asia/Kolkata; check this against a different film/city before generalizing.
- A page may contain the current selected day's sessions only. Use `available_dates` to know what dates are advertised, and fetch only approved date-specific pages if you need more.
- A page-level show count is not a platform-level show count; session IDs should be deduplicated across city boundaries.
- No web-scale bulk collection, proxy rotation, captcha bypass, login automation, or reverse-engineered private endpoints are implemented.
