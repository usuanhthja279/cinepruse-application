# Codex handoff — integrate the movie-first UI with the District extractor

You are working in the existing District movie extraction project. **Do not replace its saved HTML parser or rewrite unrelated extractor behavior.** This is the UI v2 handoff, and the files here are a standalone frontend specification and source-backed fixture, not a statement that any real-time collector is active.

## Objective

Implement a **movie-first overview with search**, then the **Ramayana** detail page with all views currently demonstrated in `index.html`: Overview, India Map, Showtime Blocks, Cities, Cinemas, Hourly Pulse, Data & Methods. Preserve responsive desktop/mobile layout, clickable navigation, region filters, sortable tables, clickable India map markers, midnight baseline, and the one-hour signal methodology.

## The provided assets

- `index.html`: self-contained, working UI prototype. Currently has a deterministic 10-city Nov 7 **simulation** and a verified 6 Nov **saved Kolkata snapshot** embedded. Read its structure, design tokens, and view labels before implementing components.
- `MOVIE_FIRST_UI_V2_SPEC.md`: updated view requirements, proven data limits, source-versus-demo distinction, and API contract.
- `DISTRICT_DATA_PRODUCT_AND_UI_SPEC_v1.md`: prior full data transformation and collector design.
- `verified_snapshot.json`: expected offline output from the saved HTML.
- `extract_html_snapshot.py`, `fixtures/*.html`: optional reproducible offline extraction and tests.

## Integrate in steps

1. Determine the existing project's framework and paths. Keep working on the current branch. Do not add Docker unless the user later requests it.
2. Port movie-first catalog and per-movie details to the existing framework, or keep the self-contained HTML if that is preferable at the present stage. The home page should search tracked movies; only Ramayana is verified in provided input.
3. Define normalized entities: Movie, Cinema, Screening (movie + cinema + session + start-date), SeatClass, Snapshot, HourlyComparison, CityCatalog, PerformanceReport. Distinguish a **city feed** from a **canonical physical cinema city**.
4. Preserve all observed sessions throughout their target day. Freeze latest valid pre-start counts for sessions that cease appearing. The midnight run defines an observed starting state, not new purchases made after midnight.
5. Calculate assumed booked+blocked, weighted occupancy and estimated listed seat value at seat-class precision; do not add values across snapshots.
6. Calculate matched-key `previous → current` net movements, positive changes, reopened seats, and value movements using both price-fixed and current-list-price definitions. Treat newly appearing/removed sessions separately. Mark missing/ambiguous data as unknown.
7. Expose data via report API matching `MOVIE_FIRST_UI_V2_SPEC.md`. Date controls must be in `Asia/Kolkata`. Support city, format and time filters and stable source timestamps. Never silently substitute demo numbers into production mode.
8. Convert the map to a properly sourced geographic view as actual cities become available. Verified November 6 feed should only display supported physical localities and a feed-coverage disclosure; do not shade uncollected states as real data. The SVG outline is illustrative and not a source of administrative borders.
9. Add automated tests for source parsing, numeric reconciliation, show de-duplication across overlapping feeds, show disappearance, changing prices, overlapping city names, blank seat classes, time-zone rollover, 00:00 baseline, and hour-to-hour differences.
10. Build, run and visually test desktop/mobile. Document exact commands for Windows PowerShell and provide a changelog of what was actually tested. Do not claim a scheduled November 7 run unless configured and observed.

## Acceptance checks

- **Catalog:** opening page is movie-first; search Ramayana finds movie; clicking opens its details; no invented real titles.
- **Details:** all seven tabs are navigable, filterable and compatible with narrow screens.
- **Verified 6 Nov mode:** totals = 29 cinemas / 117 sessions / 410 seat-class rows / 27,663 seats / 7,202 unavailable / ₹39,48,610 assumed value. Show start times must be in IST. Dayparts = 21 evening, 96 night; morning and afternoon show “No listings”. One verified snapshot must show no hourly change data.
- **Demo 7 Nov mode:** explicitly says “simulated”; hour slider and city click update charts and summaries consistently; it must never be mistaken for real booking numbers.
- **Collection:** scheduled hourly snapshots, when independently implemented, do not double-count pre-existing unavailable seats as newly booked, and do not wipe completed shows. Separate coverage warnings from actual zero-value observations.
- **Geography:** verified city and theater counts remain deduplicated even if District city pages overlap.
