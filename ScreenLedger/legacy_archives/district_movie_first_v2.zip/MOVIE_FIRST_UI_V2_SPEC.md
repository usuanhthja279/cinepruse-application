# ScreenLedger — Movie-first Product & UI Design v2

**Date:** 6 November 2026  
**Target for future collection:** 7 November 2026, starting at 00:00 Asia/Kolkata  
**Status:** Functional standalone *design prototype*, **not a running live collector**

## Product direction

The movie, not a city or individual screen, is the center of the experience. Begin at a **Discover Movies** page with search. A user selects a movie, such as **Ramayana (`MV176276`)**, and reaches an analytics page with a national geographic view, time-of-day performance, city/venue drilldowns, and hourly movement.

The page's core questions are:

1. **How is this movie doing?** Estimated value of unavailable seats; proportion unavailable; number of discovered sessions and cinemas; observation freshness.
2. **What is happening across India?** A clickable India map and city contribution rankings, with canonical physical-city ownership and no duplicate session totals.
3. **Which showtime blocks are strongest?** Morning, afternoon, evening, night, weighted by seats rather than averaging percentage observations.
4. **What changed within the last hour?** Net seat-unavailability movement between consecutive *comparable* session/category snapshots, not the difference between unrelated rosters.
5. **Which theaters drive demand?** Searchable cinema-level summary, expandable to chain, format, and price-class analyses in production.
6. **Can the user trust the numbers?** A prominent separation of verified snapshot data versus simulated UI demo, data coverage and missing-snapshot explanations.

## Information architecture implemented in `index.html`

| Surface | Main content | Working prototype controls |
|---|---|---|
| Discover | Intro, tracked-film catalog, source labels, one real source-backed movie | Movie text search, filter, click movie |
| Movie → Overview | Poster-inspired hero; estimated value, assumed seats, weighted occupancy, known shows; trajectory; leading markets; daypart summary | Switch date/data mode, region filter; view shortcuts |
| Movie → India Map | India silhouette with markers; ranked city list; click-through market filtering | Marker and region-row selection, reset region |
| Movie → Showtime Blocks | Four daypart cards plus **complete numeric table** | Region / mode filter applies |
| Movie → Cities | Market leaderboard (shows, cinemas, seats, occupancy, gross share) | Sort and select to drill to cinemas |
| Movie → Cinemas | Cinema name, locality, show count, unavailable seats, occupancy, value | Text search and region filter |
| Movie → Hourly Pulse | Selected hour, midnight baseline, current unavailable, prior-hour net change, ticket-value movement, trend and observation ledger | Interactive 00:00–23:00 hour slider (demo only) |
| Movie → Data & Methods | Source provenance, coverage, definitions and caveats | Mode-aware status facts |

The same HTML contains **all pages/views** and runs offline in Chrome/Edge, without a frontend build step or CDN. Navigation, search, filters, hour slider, and map clicks work locally. Views re-render from a shared state; they do not each maintain disconnected totals.

## Data actually supported by the attached November 6 HTML

The supplied saved HTML embeds movie, cinema, screening, and seat-class information. The accompanying `verified_snapshot.json` is a normalized offline extraction. These are its observed Kolkata-feed totals:

| Metric | Observed |
|---|---:|
| Known cinemas | 29 |
| Listed show sessions | 117 |
| Seat categories | 410 |
| Total seats in those sessions | 27,663 |
| Unavailable seats (assumed booked + blocked) | 7,202 |
| Weighted unavailable-seat fraction | 26.03% |
| Unavailable-seat listed value | ₹39,48,610 / ₹39.49 lakh |
| Feed snapshot time | 6 Nov 2026, 20:26:56 IST |

The 117 listed sessions in **this evening snapshot** break into **21 Evening** (17:00–20:59 IST) and **96 Night** (21:00–04:59 IST). **Morning and Afternoon have no listed sessions in the saved file**. The UI displays **“No listings”**, not 0% occupancy. The Kolkata *feed* contains localities labeled Kolkata (25 cinemas), Howrah (3), Serampore (1). A physical-locality split inside that feed is **not** a separately collected city-level market survey.

The map has a simplified India outline; this is a **product visualization**, not an authoritative national or state boundary map. Verified mode shows the Kolkata **feed's regional anchor only**, while its geographic leaderboard uses the cinema metadata to break out Kolkata/Howrah/Serampore. It must **not** imply that nationwide collection is currently verified.

## Demo data is not real District data

The November 7 national replay illustrates the design with 10 **fictional city metrics and hourly changes**: Mumbai, Delhi NCR, Bengaluru, Hyderabad, Kolkata, Chennai, Pune, Ahmedabad, Jaipur and Lucknow. City names and map positions are real; **show counts, occupancy, pricing, values, estimated progress and cinema rows are synthetic**. It is labeled “SIMULATED” in controls and cards. No real hourly readings, current BookMyShow data, or live collection claims are supplied.

Demo occupancy numbers depend on the hour slider; showtime-block and region summaries are internally computed from a single deterministic demo dataset for that hour. Demo hours use a stable theoretical roster. In the real service, new/disappearing sessions and price changes need separate accounting.

## Data transformation rules (critical)

The assumed occupancy rule remains the user's choice:

```text
category_unavailable = category_total - category_available
category_assumed_value = category_unavailable × category_listed_price
show_unavailable = SUM(category_unavailable)
show_assumed_value = SUM(category_assumed_value)
weighted_occupancy = SUM(unavailable) / SUM(total)
```

**Always use “unavailable”, “assumed booked + blocked”, or “estimated ticket value.”** Do not present figures as paid admissions or official ticket collections. Blocked seats may not be paid; fees, taxes, discounts, cancellations, and offline sales are not independently verified. Daily gross is an **as-of estimate for sessions on that date**, not a sum of repeated hourly observations.

To calculate real **last-hour** movement:

```text
matched = intersection(previous show/category keys, current show/category keys)
net_unavailable_movement = Σ(current_unavailable - previous_unavailable for matched)
positive_unavailability = Σ(max(0, current - previous))
seat_releases = Σ(max(0, previous - current))
volume_only_value_delta = Σ((current - previous) × previous_category_price)
listed_price_value_delta = Σ(current_unavailable × current_price - previous_unavailable × previous_price)
```

Newly discovered sessions must be counted in the *as-of show roster* but **excluded from the last-hour comparable-key movement**. A show missing once should not disappear from historical daily totals. Freeze the last reliable pre-start count for past shows. Differentiate cancellation, missing data, legitimate show additions, relisted seat classes and releases from genuine booking activity.

**Midnight on 7 November gives an observation baseline**, not a guarantee that all screenings will have been published or that there were no bookings before 00:00. Late-night shows with a start date of 7 November remain attached to that date even if they finish on 8 November.

## Backend contract to replace demo data

Expose one consistent report object per movie, performance date, as-of time, and selected canonical city scope:

```json
{
  "movieId": "176276",
  "movieTitle": "Ramayana",
  "performanceDate": "2026-11-07",
  "observedAt": "2026-11-07T13:00:00+05:30",
  "timezone": "Asia/Kolkata",
  "source": "district",
  "dataStatus": "observed_partial",
  "metricRule": "unavailable_includes_blocked",
  "coverage": {
    "cityFeedsAttempted": null,
    "cityFeedsSucceeded": null,
    "deduplicatedSessions": null,
    "staleFeeds": null
  },
  "totals": {
    "uniqueShows": null,
    "cinemas": null,
    "totalSeats": null,
    "unavailableSeats": null,
    "weightedOccupancy": null,
    "estimatedListedTicketValueINR": null
  },
  "dayparts": [],
  "cities": [],
  "cinemas": [],
  "hourlySeries": [],
  "qualityFlags": []
}
```

`null` is deliberate: the prototype does **not** have real Nov 7 readings. Prefer null/unknown over fabricated zeros. City fields should contain physical-city and source-feed IDs; regional aliases must not multiply totals. Movie catalog should be independently sourced, rather than extrapolating to titles not present in saved HTML.

## Recommended product build sequence

1. Build the **movie catalog** API and the stable movie details route; start with Ramayana; show zero additional movies until reliably discovered.
2. Add authorized **multi-city movie/session collection** and stable session+seat-category registry for the selected performance date.
3. Run hourly snapshots from 00:00 IST, save first observation as a baseline, maintain frozen pre-start session totals.
4. Materialize a report view with consistent geographic/daypart/hourly definitions and source freshness.
5. Replace the prototype's JS demo numbers with the report API; preserve simulated data only as a developer demonstration mode.
6. Implement and test coverage quality, duplicate suppression, price changes, unknown values and limited geographic availability before publishing any nationwide headline.

For the extractor's detailed schema, implementation edge cases, and provenance notes, see the accompanying original `DISTRICT_DATA_PRODUCT_AND_UI_SPEC_v1.md`.
