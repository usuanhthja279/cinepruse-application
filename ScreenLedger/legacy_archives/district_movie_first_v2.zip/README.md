# ScreenLedger — Movie-first responsive HTML prototype (v2)

## Open the dashboard

Open `index.html` directly in **Chrome or Edge** (Windows: double-click or `Start-Process .\index.html`). All CSS and JavaScript are embedded; no internet, backend, Node install or web server is required. The HTML is a **functional prototype**, not a live data service.

The landing page is now a **searchable movie catalog**. Choose **Ramayana** to open its detail page. Seven clickable tabs cover Overview, India Map, Showtime Blocks, Cities, Cinemas, Hourly Pulse and Data & Methods. City filters and market map markers change the visible metrics; the hour slider demonstrates a 24-hour as-of progression.

## Data selection

The default **7 Nov 2026 interactive demo** has fictional metrics across 10 real Indian city locations for visualizing future nationwide coverage. All other-city collection and hourly values are simulated and labeled as such. **6 Nov 2026 verified snapshot** uses only the actual *saved Kolkata-region District HTML* and disables hourly trend claims. Its true totals are 117 shows, 29 cinemas, 27,663 total seats, 7,202 unavailable, **₹39,48,610** listed unavailable-seat value, captured at **20:26:56 IST**. This is not a complete day or an all-India total.

The India map silhouette is an offline illustrative outline generated using the `countryinfo` package's public geographic data; do not treat it as authoritative political boundaries or state borders.

## Package contents

- `index.html`: revised self-contained responsive movie-first prototype.
- `MOVIE_FIRST_UI_V2_SPEC.md`: product goals, source versus simulated data, all views, formulas, API contract, implementation sequence.
- `CODEX_UI_V2_IMPLEMENTATION.md`: an actionable Codex handoff with acceptance tests.
- `DISTRICT_DATA_PRODUCT_AND_UI_SPEC_v1.md`: original detailed data analysis carried forward.
- `verified_snapshot.json`: normalized evidence used in verified mode.
- `fixtures/ramayana_kolkata_2026-11-06.html`, `extract_html_snapshot.py`, `requirements.txt`: offline regeneration inputs.
- `desktop_preview.png`, `mobile_preview.png`: browser screenshots of the revised responsive detail view.

The dashboard is an independent collection/availability estimation design, not an official District or BookMyShow reporting service. The user's policy deliberately counts all **unavailable** seats as assumed booked, including held/blocked seats; all resulting ticket value is estimated, not verified paid revenue.
