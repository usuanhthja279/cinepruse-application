"""Offline District HTML snapshot normalizer, no network access.
Run: python extract_html_snapshot.py --html fixtures/ramayana_kolkata_2026-11-06.html --out verified_snapshot.json
"""
import argparse
import json
from datetime import datetime, timezone, timedelta
from pathlib import Path
from bs4 import BeautifulSoup


def extract(path):
    soup = BeautifulSoup(Path(path).read_text(encoding='utf-8'), 'html.parser')
    el = soup.find('script', id='__NEXT_DATA__')
    if el is None:
        raise ValueError('No __NEXT_DATA__ script in source HTML')
    obj = json.loads(el.string)
    server = obj['props']['pageProps']['data']['serverState']
    ses = next(iter(server['movieSessions'].values()))
    cinemas = []; show_records=[]; class_count=0
    for c in ses['arrangedSessions']:
        agg={'seats':0, 'booked':0, 'gross':0, 'shows':0}
        for ss in c.get('sessions',[]):
            seats=booked=gross=0
            for area in ss.get('areas',[]):
                class_count+=1
                total=area.get('sTotal') if area.get('sTotal') is not None else area.get('seatsTotal')
                avail=area.get('sAvail') if area.get('sAvail') is not None else area.get('seatsAvail')
                if total is None or avail is None or area.get('price') is None:
                    continue
                total=int(total);avail=int(avail)
                if total<0 or not 0<=avail<=total:
                    raise ValueError(f'Invalid seat inventory: cinema={c["entityCode"]}, session={ss.get("sid")}')
                unavailable=total-avail
                seats+=total;booked+=unavailable;gross+=unavailable*float(area['price'])
            # For this saved fixture, showTime is UTC and user-facing event time is +05:30.
            show_at=datetime.fromisoformat(ss['showTime']).replace(tzinfo=timezone.utc).astimezone(timezone(timedelta(hours=5,minutes=30)))
            dp='Morning' if 5<=show_at.hour<12 else 'Afternoon' if show_at.hour<17 else 'Evening' if show_at.hour<21 else 'Night'
            show_records.append({'key':f"176276:{c['entityCode']}:{ss['sid']}:{ss.get('mid','')}", 'cinema_id':str(c['entityCode']),'cinema_name':c['entityName'],'showtime_ist':show_at.isoformat(timespec='minutes'),'daypart':dp,'format':ss.get('scrnFmt') or '?','total':seats,'assumed_booked':booked,'estimated_gross':int(gross)})
            agg['seats']+=seats;agg['booked']+=booked;agg['gross']+=gross;agg['shows']+=1
        cinemas.append({'id':str(c['entityCode']),'name':c['entityName'],'place':c['data'].get('city'),'chain':c['data'].get('chainKey') or 'Other','shows':agg['shows'],'seats':agg['seats'],'booked':agg['booked'],'gross':int(agg['gross']),'occupancy':round(100*agg['booked']/agg['seats'],2) if agg['seats'] else None})
    totals={'cinemas':len(cinemas),'shows':len(show_records),'seats':sum(c['seats'] for c in cinemas),'booked':sum(c['booked'] for c in cinemas),'gross':sum(c['gross'] for c in cinemas),'seat_categories':class_count}
    return {'source':'Provided District Kolkata HTML snapshot','movie':'Ramayana','movie_id':'176276','city_feed':'kolkata','snapshot_at_ist':datetime.fromtimestamp(ses['serverTime'],timezone(timedelta(hours=5,minutes=30))).isoformat(),'totals':totals,'cinemas':cinemas,'shows':show_records}


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--html',required=True);p.add_argument('--out',default='verified_snapshot.json');args=p.parse_args()
    result=extract(args.html)
    Path(args.out).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print('Offline validation:', result['snapshot_at_ist'],result['totals'])
