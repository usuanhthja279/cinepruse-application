# District Movies — Data Product and Responsive Dashboard Blueprint

**Version:** 1.0 · **Prepared:** 6 November 2026 · **Target first daily run:** 7 November 2026, 00:00 IST  
**Movie used for validation:** *Ramayana* (`176276`) · **Primary input:** user-supplied District Kolkata HTML snapshot  
**Deliverables alongside this specification:** `district_dashboard_prototype.html` (single-file interactive prototype), `verified_snapshot.json` (audited offline source-derived metrics).

## 1. Product idea: turn an extraction into a story people can understand

A raw list of showtimes and seat categories is useful to developers but not to viewers. The product should answer, quickly:

- **How is the film doing now?** Estimated gross ticket value, assumed booked-or-blocked seats, weighted occupancy, and discovered unique shows, with an *as-of* timestamp and data coverage indicator.
- **What changed in the last hour?** Net change in unavailable seats and ticket value *on matched show sessions*; separately report newly appearing, canceled, or missing sessions. This is a **proxy**, not a verified count of new purchases.
- **Which cities contribute most?** Ranked city-wise gross, seats, show counts and occupancy, with metropolitan overlap eliminated.
- **Which screening times perform best?** Morning, afternoon, evening, night groupings based on show **start time in IST**, displaying weighted occupancy and estimated gross for each.
- **Is demand growing through the day?** Hourly trend of seat availability *for the target date's sessions*, with the meaning of pre-booked baseline versus hourly change clearly explained.
- **Where is the strongest performance?** Cinema, chain, format, language and price-band comparisons; filter and drill down instead of forcing users to scan every show row.

**Recommended name:** ScreenLedger — Movie Performance Intelligence. It is an **independent estimated ticket-availability analytics concept**, not District's official box-office reporting.

## 2. What the provided HTML actually contains

The saved page embeds Next.js `__NEXT_DATA__`, including `serverState.movieSessions` and movie metadata. The extractor can read the following *when present*:

| Domain | Available data | UI transformation |
|---|---|---|
| Movie | Content ID, name, metadata, languages, format group, genre, runtime, poster | Movie identity hero; language/format tabs |
| Cinema | Cinema/provider identifiers, name, address, parent chain, city/region, coordinates, amenities | Cinema ranking, chain performance, drill-down; potential map later |
| Screening | Stable session identifiers, auditorium, show time, format, show status | Distinct shows per date, performance by time block, cinema schedule |
| Pricing | Ticket price and seat-category label for every reported category | Ticket-value estimate, revenue contribution by seat class, category pricing mix |
| Seat inventory | Total and available seats per class | Assumed booked-or-blocked count and weighted occupancy |
| Collection metadata | City feed name, page timestamp/server time, search date, show dates | Freshness, coverage audit, scheduled-date tracking |
| Editorial | Film description, cast, rating/reviews where supplied | Optional film details, separate from booking analytics |

Not every field is always supplied or trustworthy (e.g. some free-seating sessions). Mark missing data as unknown; do **not** convert missing seats or prices to zero and silently include them in totals.

### Confirmed snapshot, **not a full day's market total**

Parsed from the supplied Kolkata movie page, with the page's own `serverTime` of **6 Nov 2026, 20:26:56 IST**:

| Metric | Observed value |
|---|---:|
| Listed cinema entities | 29 |
| Listed unique sessions in this snapshot | 117 |
| Seat category rows | 410 |
| Seat capacity represented | 27,663 |
| Unavailable = assumed booked + blocked | 7,202 |
| Weighted unavailable/occupancy rate | 26.03% |
| Estimated listed ticket value of unavailable seats | **₹39,48,610 (₹39.49 lakh)** |

This snapshot is for District's **Kolkata feed** and includes nearby places such as Howrah and Serampore. Do not mistake it for Kolkata municipality-only counts. It is neither an all-India count nor a final daily collection figure.

## 3. Agreed business rule — collection estimation

The project currently deliberately treats **all unavailable seats as assumed booked, INCLUDING blocked/held seats**.

For each seat category in a screening:

```text
assumed_unavailable_seats = max(0, seat_total - seat_available)
estimated_ticket_value = assumed_unavailable_seats × listed_category_price
```

Across categories in one show:

```text
show_assumed_booked = SUM(category_assumed_unavailable_seats)
show_estimated_gross = SUM(category_estimated_ticket_value)
show_occupancy = SUM(category_assumed_unavailable_seats) / SUM(category_seat_total)
```

Aggregate **unique shows** into cinema, city, daypart, format, and all-tracked-India totals. **Never sum hourly snapshots together:** the same unavailable seat would be counted many times. Occupancy must be weighted (`SUM booked / SUM capacity`), not a simple average of show percentages.

**Label everywhere:** “Estimated gross ticket value (booked + blocked assumption).” This is **not actual paid tickets, GST-adjusted net revenue, official gross box office, or verified admissions**. Ticket prices can change between snapshots; preserve the price seen at each snapshot for an auditable comparison.

## 4. November 7 midnight start: the accurate operational interpretation

**Start the first authorized run at 00:00 IST on 7 Nov 2026**, then run once per hour. This creates a consistent observation series. However, **midnight does not guarantee all screenings are published**, and it cannot recover transactions made **before** the first snapshot. Shows may be added/removed during the day; some become unlisted once they begin or finish. Therefore the midnight listing is a *baseline*, not the certified entire day's schedule or full-day sales ledger.

Recommended operational sequence:

1. **00:00** — fetch the target date's show roster for each validated city/movie (with approved access), persist each unique screening and its class-level counts. Classify already-unavailable seats as **pre-existing baseline**.
2. **01:00, 02:00, ... 23:00** — collect current lists and update all eligible scheduled shows; discover new sessions without treating their pre-existing unavailable seats as “booked in the last hour.”
3. **Before each show starts** — freeze its latest valid pre-show values as its *final observed occupancy*. A screening that disappears after showtime remains in the day's historical total.
4. **23:00 / next midnight** — finalize remaining late shows using last observed values. Label all unresolved/never-collected sessions separately. Continue collecting future dates if advance ticket sales are desired.
5. **Post-run checks** — flag missing cities, stale snapshots, duplicate sessions, missing price/seat classes, session schedule changes, and source errors.

**Timezone:** source `showTime` values in this snapshot appear in UTC while the page's user-facing screening times are IST. Normalize to `Asia/Kolkata` before assigning show date and time block. Store both raw timestamp/timezone interpretation and normalized IST time. For example, source `2026-11-06T16:15` corresponds to **21:45 IST**, not 16:15 IST, for the confirmed Cinepolis show.

## 5. The most important analytic distinction: 3 different clocks

1. **Observation time:** when the extractor saw availability — e.g. 10:00 AM.
2. **Show start time:** when the actual screening begins — e.g. 7:00 PM.
3. **Performance date:** the local date on which the show starts — e.g. 7 Nov.

A 10:00 AM snapshot contains booking-status data for evening shows, too. It must *not* be interpreted as “morning show collections.” Likewise, seats already unavailable at 00:00 are **baseline demand**, not sales during 00:00–01:00.

For a target day, maintain:

- **As-of inventory:** one most-recent valid snapshot for each future/unstarted show, plus frozen final pre-start snapshot for completed shows. This gives the observed *whole-day schedule's* current assumed ticket value, with qualifications.
- **Hourly net change:** difference between *matched, still-comparable* show/category inventories at two sample times, broken into positive increases and negative releases. Never claim this is an exact purchase count.
- **Final observed demand:** for each session, the most recent reliable **pre-show** observation; aggregate once across the day's show roster.

### Correct last-hour calculation

```text
matched_show_category_keys = intersection(previous_snapshot, current_snapshot)
net_new_unavailable = SUM(current_unavailable - previous_unavailable for matched keys)
positive_unavailable_movements = SUM(max(0, difference))
released_or_reopened_seats = SUM(max(0, -difference))
matched_ticket_value_delta = SUM(
    current_unavailable * current_price
    - previous_unavailable * previous_price
)
```

If prices changed, additionally show a **seat-volume-only value delta** holding prior prices fixed. Show **newly discovered sessions** as their own separate contribution to the *as-of total*, not as one-hour sales; show **disappeared sessions** as “unobserved” until confirmed rescheduled/canceled or frozen at pre-start time. A negative delta may reflect cancellations, released blocks, or inventory corrections. Hourly figures are net availability movements, *not exact completed purchases*.

### Daypart definitions (editable product choice)

| Daypart | Local show start (IST) |
|---|---|
| Morning | 05:00–11:59 |
| Afternoon | 12:00–16:59 |
| Evening | 17:00–20:59 |
| Night | 21:00–04:59 (start dates roll over at midnight) |

These buckets classify **show starts**, while the hourly chart classifies **observation times**. Night starts 00:00–04:59 belong to their true calendar date; clarify this in the tooltip.

## 6. What the user should see (view-by-view)

| View | Main visual / controls | User question answered |
|---|---|---|
| Overview | 4–5 headline KPIs, freshness and confidence strip, cumulative observed-value chart | How is it doing overall and is this data fresh? |
| Hourly pulse | Time scrubber, baseline vs hourly deltas, hourly positive and negative changes | What has changed since the prior run? |
| Cities | Sortable ranking and contribution bars, city selection and drill-down | Which cities drive ticket value? |
| Dayparts | Four comparison cards, occupancy bars, gross contribution | Which screening slots are strongest? |
| Cinemas | Searchable cinema leaderboard, chain, format filters | Which cinemas are the strongest? |
| Coverage & quality | City coverage, unique show dedup status, last success and known gaps | How reliable is the picture? |
| Methodology | Plain-English formulas and important caveats | What exactly does “collection” mean? |

For premium presentation: make the *movie* the subject; present numeric KPIs on a restrained dark canvas with small accent colors, emphasize a single chart per section, use readable Indian currency notation (lakh/crore), and avoid overloaded chart legends. On mobile: stack cards, collapse the sidebar, give tables horizontal scrolling, and preserve filters at the top.

**Useful insight callouts** (only when computed): “Evening occupancy is 1.4× afternoon,” “City X accounts for 18% of tracked gross,” “last-hour unavailability +482 seats with 71 released,” “3 cities not refreshed,” “New show discovered at 14:00.” Never manufacture insights when source coverage is insufficient.

## 7. Minimal persistence schema: do not discard every show immediately

The proposed UI needs aggregates, but trustworthy aggregates **depend on session identity**. Do not store seat maps or personal seat details; preserve compact **per-show, per-category** numeric state, plus hourly aggregate summaries. This is relatively small and prevents double counting, disappearing-show loss, and false 1-hour changes.

| Table / file | Suggested key | Keep |
|---|---|---|
| `city_catalog` | District city ID / slug | raw name, canonical region, provenance, validation status, overlap mapping |
| `screening_registry` | movie ID + cinema ID + session ID + session/show date (+ source provider if needed) | first/last seen, start time, status, format, canonical physical city, final pre-start values |
| `category_snapshot` | screening key + category ID + observed timestamp | capacity, available, listed price, validity, raw origin |
| `hourly_city_aggregate` | movie + target date + city + observation hour | count of shows, currently observed unavailable seats, gross, matched-net change, new/missing shows, freshness |
| `daypart_aggregate` | movie + target date + daypart + observation hour | weighted capacity, booked count, gross, show count |
| `run_audit` | run ID + source city | start/finish, success/failure, retries, freshness, rows validated, warnings |

Retention: retain category-level hourly state for enough time to audit and rebuild metrics (initially at least 30 days), then optionally compact older observations into daily stats while preserving each show's closing observation. Keep raw HTML only if permitted and within a defined retention policy. A direct official feed or other authorized access is preferable to bulk scraping; respect site access restrictions and rate limits.

## 8. Identity and city coverage pitfalls

The user requested prioritizing up to **500 cities**, but the **official complete District city roster and its share of screenings remain unverified**. Use city discovery/validation before nationwide reports. A Mumbai feed and adjacent metropolitan feed may contain the same cinema. Deduplicate by **screening identity**, not by city name or cinema text.

Use two geography fields: `source_feed_city` (which URL returned it) and `canonical_physical_city` (where the theater is). For geographical totals, assign a show to **one canonical physical region**. Allow a separate user-facing “Greater Kolkata” metro view if explicitly labeled. Report city coverage: `successfully_refreshed / expected`, missing shows/cities, and timestamp range. Never claim 99% of shows from a 500-city input list without measuring the denominator.

## 9. Implementation acceptance criteria

- Test the offline fixture first: **29 cinemas, 117 shows, 410 categories, 27,663 seats, 7,202 unavailable, ₹39,48,610 estimated gross**.
- First collection for 7 Nov at midnight is stored as a **baseline**, not hourly sales.
- Two repeated identical snapshots add **zero** hourly net movement and do not increase cumulative gross.
- If a show disappears after start, it stays in daily show count and contributes its last valid pre-start observation exactly once.
- When a show appears at 14:00, its already-unavailable seats contribute to current baseline but **not** matched one-hour movement.
- A seat-release scenario decreases the net movement; track increases and releases separately.
- Missing or stale city data causes a quality warning; never silently report an all-India “actual” collection.
- Cross-feed duplicate screenings have one ledger identity and one estimated value.
- Currency values are INR; timestamps displayed in IST; night-time boundaries verified; percentages weighted by capacity.
- Responsive prototype operates offline with functioning navigation, time controls, filters, search, data-mode labels and downloadable reference files.

## 10. What is and isn't implemented in the supplied prototype

The standalone HTML includes **all primary views** in one page; navigation, scope/daypart/chain filtering, hourly slider, chart states, search and live KPI re-rendering are interactive. It has two **clearly separated sources**:

- **Verified saved page:** Kolkata-feed snapshot of 6 Nov 2026 at 20:26:56 IST. Values and cinema leaderboard are sourced from `verified_snapshot.json`. There is **no historical hourly trend** available from that single snapshot.
- **Illustrative replay:** simulated hourly 7 Nov 2026 data for multiple example cities, solely to test layout and behavior. These figures are NOT District data and must not be treated as verified market estimates.

The HTML has no backend and makes **no network requests**. To make it production-ready, replace demo state with your authorized collector's normalized response, implement immutable run audits, add tested show-key matching, and connect future/expired show persistence. The standalone prototype is a UX and information-architecture artifact, **not** a deployed or scheduled scraper.

## 11. Suggested implementation order for Codex

1. Verify the actual District city roster, establish canonical city/metro mapping and permitted collection method.
2. Build the dated, timezone-aware show registry and latest pre-start availability snapshot, preserving movie/cinema/session/category keys.
3. Run one authorized city end-to-end; test hourly matched deltas and reappearance/cancellation scenarios.
4. Add city/daypart/chain aggregation and run-health APIs with snapshot coverage metadata.
5. Integrate the prototype views with normalized backend data; ensure every chart explains baseline vs booking movements.
6. Expand the monitored city set gradually, dedupe sessions across feeds, and publish measured geographic coverage.
7. Configure the midnight + hourly Windows scheduled task using an idempotent job, retries, and auditable logs. **No automation has been started by this design document.**

---

**Bottom line:** The compelling product isn't a wall of show rows. It is a **dated, hourly, explainable movie-performance ledger** showing estimated booked+blocked value, time-block occupancy, location contribution, and change since the last observation—without confusing seat unavailability with actual sales.
