# ScreenLedger — District Dashboard Design Pack

This package is an **add-on to the previously discussed District Movie Extractor v2**, not a replacement for the extractor. The previous v2 ZIP was not available to merge into this session, so the files here are self-contained design, prototype and offline validation assets.

## Open the interactive HTML prototype

On Windows, unzip this folder and **double-click** `district_dashboard_prototype.html` in Chrome or Edge. Alternatively:

```powershell
Start-Process .\district_dashboard_prototype.html
```

No installation, web server, or internet connection is needed. There are **seven clickable views**: Overview, Hourly Pulse, City Performance, Showtime Analysis, Cinema Explorer, Data Coverage, and Methodology.

Use the top **data mode** picker:

- **Nov 7 · demo replay:** responsive multi-city dashboard with simulated numbers, a working 00:00–23:00 hourly slider, and dynamic charts. **NOT live District data.**
- **Nov 6 · verified HTML:** real metrics parsed from the included user-supplied saved Kolkata page. One snapshot only, so last-hour changes are not available. Saved HTML timestamp: **2026-11-06 20:26:56 IST**.

City selection, city sorting, cinema-chain selection, cinema search, and clickable navigation work. Values update when you use the controls.

## Files

| File | Purpose |
|---|---|
| `DISTRICT_DATA_PRODUCT_AND_UI_SPEC.md` | Full analysis, formulas, source fields, data design, dashboard views, quality criteria |
| `district_dashboard_prototype.html` | Complete self-contained responsive HTML/CSS/JS prototype; real snapshot embedded, fictional 7 Nov replay clearly separated |
| `verified_snapshot.json` | Parsed and validated offline snapshot: real cinema, show, capacity, prices aggregated to ticket-value estimates |
| `CODEX_IMPLEMENTATION_HANDOFF.md` | Specific implementation instructions for integrating the views with the existing collector |
| `fixtures/ramayana_kolkata_2026-11-06.html` | Supplied HTML saved page (offline fixture) |
| `extract_html_snapshot.py` | Regenerate verified summary from supplied fixture; no live fetching |
| `requirements.txt` | Optional dependency used only for regeneration |
| `desktop_preview.png` / `mobile_preview.png` | Screenshots of the demo layout |

## Rebuild verified source JSON (optional)

```powershell
py -3 -m pip install -r requirements.txt
py -3 extract_html_snapshot.py --html fixtures/ramayana_kolkata_2026-11-06.html --out verified_snapshot.json
```

Expected: **29 cinemas, 117 shows, 410 seat categories, 27,663 seats, 7,202 assumed booked/blocked, ₹39,48,610 estimated listed ticket value**.

## About the first 7 November collection

For the first **real** run, configure an authorized collector on your own machine for **2026-11-07 00:00 IST** and hourly thereafter. This package **does not schedule or execute** future work. Starting at midnight gives a useful baseline but **not necessarily all published shows** nor any sales made before midnight; the collector must preserve disappearing shows, handle newly appearing sessions and deduplicate overlapping city feeds. These requirements are documented in the spec and Codex handoff.
