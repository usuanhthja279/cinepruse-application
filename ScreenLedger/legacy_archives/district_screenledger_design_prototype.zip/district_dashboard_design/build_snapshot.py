import json
from pathlib import Path
from datetime import datetime, timezone, timedelta
from bs4 import BeautifulSoup
root=Path('/mnt/data/district_dashboard_design')
soup=BeautifulSoup(Path('/mnt/data/Pasted text(3).txt').read_text(encoding='utf-8'),'html.parser')
state=json.loads(soup.find('script',id='__NEXT_DATA__').string)['props']['pageProps']['data']['serverState']
sessions=next(iter(state['movieSessions'].values()))
cinemas=[]; show_records=[]; seat_rows=0
for c in sessions['arrangedSessions']:
    sums={'seats':0,'unavailable':0,'gross':0,'shows':0}
    for ss in c['sessions']:
        subtotal=0;unavailable=0;total=0
        for area in ss.get('areas',[]):
            seat_rows+=1
            cap=area.get('sTotal') if area.get('sTotal') is not None else area.get('seatsTotal')
            avail=area.get('sAvail') if area.get('sAvail') is not None else area.get('seatsAvail')
            if cap is None or avail is None: continue
            cap=int(cap);avail=int(avail);price=float(area.get('price') or 0)
            count=max(0,cap-avail)
            subtotal+=count*price;unavailable+=count;total+=cap
        dt=datetime.fromisoformat(ss['showTime']).replace(tzinfo=timezone.utc).astimezone(timezone(timedelta(hours=5,minutes=30)))
        sums['seats']+=total;sums['unavailable']+=unavailable;sums['gross']+=subtotal;sums['shows']+=1
        show_records.append({'key':f"176276:{c['entityCode']}:{ss['sid']}:{ss.get('mid','')}", 'cinema_id':str(c['entityCode']), 'cinema_name':c['entityName'], 'showtime_ist':dt.isoformat(timespec='minutes'),'daypart':('Morning' if dt.hour<12 else 'Afternoon' if dt.hour<17 else 'Evening' if dt.hour<21 else 'Night'), 'format':ss.get('scrnFmt') or '?','total':total, 'assumed_booked':unavailable, 'estimated_gross':int(subtotal)})
    cinemas.append({'id':str(c['entityCode']),'name':c['entityName'],'place':c['data'].get('city'),'chain':c['data'].get('chainKey') or 'Other','shows':sums['shows'],'seats':sums['seats'],'booked':sums['unavailable'],'gross':int(sums['gross']),'occupancy':round(100*sums['unavailable']/sums['seats'],2) if sums['seats'] else None})
alltot={'cinemas':len(cinemas),'shows':len(show_records),'seats':sum(x['seats'] for x in cinemas),'booked':sum(x['booked'] for x in cinemas),'gross':sum(x['gross'] for x in cinemas),'seat_categories':seat_rows}
print('STATS',alltot)
root.joinpath('verified_snapshot.json').write_text(json.dumps({'source':'Provided District Kolkata HTML snapshot','movie':'Ramayana','movie_id':'176276','city_feed':'kolkata','snapshot_at_ist':datetime.fromtimestamp(sessions['serverTime'],timezone(timedelta(hours=5,minutes=30))).isoformat(),'totals':alltot,'cinemas':cinemas,'shows':show_records},indent=2,ensure_ascii=False),encoding='utf8')
