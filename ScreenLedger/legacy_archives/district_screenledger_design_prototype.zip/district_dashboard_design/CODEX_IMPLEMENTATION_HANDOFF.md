# Codex handoff — District Movie Analytics

Continue development in the **existing** `district_movie_extractor` project. Do not recreate the extractor from scratch or redesign unrelated code. Read `DISTRICT_DATA_PRODUCT_AND_UI_SPEC.md` and `district_dashboard_prototype.html` before changes.

## Goal

Create a dated movie-performance ledger with hourly snapshots, estimated booked+blocked value, city and time-of-day aggregates, one-hour availability movements, quality flags and an API that can power all seven views in the standalone HTML prototype.

## Requirements

1. **Source and permission:** Use existing authorized inputs. Do not bypass CAPTCHAs, authentication, rate limits, robots/terms or protected APIs. Allow saved HTML fixture parsing without network calls.
2. **Validate fixture first:** `29` cinemas, `117` sessions, `410` classes, `27,663` seats, `7,202` unavailable, `₹39,48,610` gross proxy. Reconcile exact figures with `verified_snapshot.json`.
3. **Day and timezone:** User's first target date is **2026-11-07, Asia/Kolkata**. Local show start is distinct from scrape timestamp. Parse and normalize source UTC show times correctly. Discover all sessions for the target date, retain those that vanish after start; do not assume the first midnight feed is exhaustive.
4. **Persistence:** Retain a stable show registry and compact class-level snapshot ledger, not just hourly sums. Use movie ID + cinema ID + provider/session ID + day/format as appropriate. Distinguish source feed from canonical physical city.
5. **Hourly comparisons:** First 00:00 snapshot is pre-existing baseline. For last-hour delta, compare only matched class identifiers across consecutive valid observations. Track positive unavailable changes, negative reversals, newly discovered sessions, disappeared sessions, and changed prices **separately**. Do not claim unavailability change equals paid tickets.
6. **As-of gross and final estimated gross:** Per class, `max(0,total-available)*price`. Aggregate each session only once. For elapsed shows, use the last valid **pre-start** observation; do not discard show on disappearance. Calculate occupancy as `SUM unavailable / SUM capacity`.
7. **Views/API:** Implement overview, hourly pulse, city contribution, daypart (morning/afternoon/evening/night), cinema explorer, data coverage/quality and methodology, using the HTML prototype as a UI specification. Expose `data_mode`, `as_of`, `timezone`, `source`, `coverage`, `estimated` prominently.
8. **Schedule:** Add **documented Windows Task Scheduler** instructions for local execution at 00:00 IST and hourly after; idempotent re-runs, low request rate, timeouts/backoffs, logs and resume. Do not claim scheduler registration until executed by the user or a confirmed tool action.
9. **City roster:** Obtain and validate actual District identifiers/slugs from an authorized source; retain candidate city list separately. Handle metro duplicates and rank measured unique-show contribution. Do not claim top 500 cities reach 99% until evidenced.
10. **Tests:** No double counting from repeated snapshots; midnight baseline not hourly sales; added show not counted as hour sales; canceled/disappearing show preserved; corrections/releases may yield negative delta; cross-feed duplicates counted once; timezone late-night boundaries; missing/invalid class prices or capacities flagged; API and UI mode labels never show demo data as actual.

## Outputs expected

- Implementation plan and files changed (preserve current project structure).
- Reproducible offline extraction tests and an API response fixture for the UI.
- Working UI integration or documented next steps, with coverage, request limits and missing-source limitations.
- Sample rollups for **one authorized city** before expanding to the full roster.

**Critical:** Screenshot/demo data in the HTML is *fictional*. Actual historical hourly booking counts for **7 November 2026** do not exist in the saved 6 November fixture.
