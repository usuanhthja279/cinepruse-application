# ScreenLedger — movie-first dashboard + India state drilldown v3

Open **`index.html`** in a modern browser. Search/select **Ramayana** and open the **India Map** tab. The previous analytics tabs are preserved. State and Union Territory index navigation, state detail with cities/districts/cinemas, verified Kolkata-area data, and simulated hourly replay work without additional dependencies.

**To draw geographically accurate clickable states**, obtain `state_NWIC_GeoJSON.zip` from the [Government of India National Water Data Portal](https://nwdp.nwic.gov.in/dataset/state-boundary). Import it with the State GeoJSON/ZIP picker, or try the direct fetch (may fail due to browser CORS). Optionally import the official district GeoJSON. **Compare the resulting borders against the latest 2026 [Survey of India Political Map](https://surveyofindia.gov.in/pages/political-map-of-india) before publication.** This prototype does not ship unverified polygons; the missing-file state is deliberate, not a UI crash.

Read **`INDIA_STATE_DRILLDOWN_V3_SPEC.md`** for provenance, data assumptions, screenshots/test scope, and limitations. **`CODEX_INDIA_MAP_V3_HANDOFF.md`** contains the next integration tasks. The older v2 specification remains for legacy screens.

Dataset status: the verified 6 November 2026 saved Kolkata HTML contains 117 sessions / 29 cinemas / 27,663 seats / 7,202 unavailable / ₹39,48,610 assumed value; the nationwide November 7 replay is **SIMULATED**, not an actual collection run. Last-hour verified movement is unavailable with one snapshot. ZIP contains no runtime connection to a real District collector.
