# ScreenLedger — India State / District Drilldown v3

**Date:** 6 November 2026  
**Scope:** Extend the existing movie-first HTML prototype; preserve all seven v2 views.  
**Status:** State-navigation and drilldowns tested on desktop/mobile. Government geographic polygons are not yet bundled; they load only from an authentic government GIS file.

## Experience

Like an election-night results map, navigation is hierarchical:

**Movie search → Ramayana → India map → state/UT → district or city → cinema**.

The India view has 36 state/UT entries, a search box, interactive import of government polygon data, and a map where official polygon geometry is loaded. States with available source information get a contrasting fill; others are shown as **not collected**, not zero. Hovering a polygon displays the state name, known show count, weighted occupancy, listed unavailable-seat value and last-hour signal (when two comparable samples exist). Clicking opens a responsive state details dialog with tabs for **Cities, Districts, and Cinemas**. States can be opened from the index even if their polygons have not been loaded.

Within a state, top cards show the discovered show count, unavailable-seat weighted occupancy, last-hour change, and estimated listed ticket value. A city row drills through to the existing cinema table. The state detail maintains its own dialog, including responsive mobile layout and keyboard dismissal.

For **West Bengal** the saved 6 November snapshot can be split by physical venue locality: Kolkata, Howrah, Serampore. Durgapur and Siliguri are shown as not collected. These **do not** imply complete coverage of West Bengal. On 6 November there is only one saved source observation, so last-hour changes are unavailable. The 7 November simulated replay remains separately labeled as a demonstration, not a real historical run.

## Official geographic sources

1. **Survey of India (SoI), Government of India:** [Political Map of India, English 13th edition (2026)](https://surveyofindia.gov.in/pages/political-map-of-india). Use this as the definitive cartographic reference for the national external border and state/UT depiction, including Jammu & Kashmir and Ladakh.
2. **National Water Data Portal (NWIC), Government of India:** [State Boundary dataset](https://nwdp.nwic.gov.in/dataset/state-boundary), resource `state_NWIC_GeoJSON.zip`, metadata updated 1 October 2026. The resource itself reports GeoJSON data last updated 1 May 2025. This is a government-hosted GIS file and its outer boundary still needs visual cross-checking against the newer 2026 SoI political map.
3. **NWIC, Government of India:** [District Boundary dataset](https://nwdp.nwic.gov.in/dataset/district-boundary). Optional official district polygons for the selected-state geographic layer.
4. **Survey of India:** [Administrative Boundary Database](https://surveyofindia.gov.in/pages/administrative-boundary-data-base-abdb-), which provides official administrative geometry, including subdivisions.

**Provenance constraint:** The original v2 SVG silhouette was simplified and not authoritative. It is hidden in v3. There are **no synthetic geopolitical boundary shapes** in the shipped v3 HTML. The rendering code accepts a user-imported government GeoJSON/ZIP, checks for separate Jammu & Kashmir and Ladakh features, then renders and makes polygons interactive. This minimal check is not enough to certify the whole northern border or other border changes; a human must compare the resulting geometry against the 2026 Survey of India map before publication. If the official ZIP cannot be downloaded programmatically, import it manually. The site should not call the map government-certified until this verification is complete.

## Import the map into the standalone prototype

1. Open `index.html` in Chrome/Edge; open Ramayana and its **India Map** tab.
2. Open the government [State Boundary dataset](https://nwdp.nwic.gov.in/dataset/state-boundary), download `state_NWIC_GeoJSON.zip`, and import the ZIP using **Import official state GeoJSON / ZIP**. You can also try **Fetch official ZIP**; network/CORS restrictions may prevent it, in which case manual import is supported.
3. The map will render true polygon geometry from the imported file. Hover/click state polygons. To see sub-state boundary polygons, repeat using the [district dataset](https://nwdp.nwic.gov.in/dataset/district-boundary) with **Optional: import district GeoJSON / ZIP**.
4. Compare the resulting **entire** north and the state/UT boundaries against the **Survey of India 2026 map** before public deployment. The UI flags the lack of separate Jammu & Kashmir/Ladakh geometries and refuses to render if they are missing.

The government GeoJSON is **not included** in the ZIP due to the unavailable download from the sandbox. The prototype works offline for all remaining state, city, and cinema navigation without it. Any generated preview used for functional testing is not representative of official geography.

## Metrics and backend contract

For a deduplicated `(movie, performance_date, state_code, as_of)` scope:

```text
shows = count(distinct normalized_screening_id)
cinemas = count(distinct normalized_cinema_id)
seat_capacity = sum(screening_seat_class.total_seats)
unavailable = sum(total_seats - available_seats)
weighted_occupancy = unavailable / seat_capacity
assumed_ticket_value_inr = sum(unavailable_seats * listed_price_inr)
last_hour_net_unavailable = sum(matched_shows.current_unavailable - matched_shows.previous_unavailable)
```

Last-hour metrics require matching show and seat category across hourly captures. New shows are counted in current full-day totals but excluded from comparable last-hour booking movement. Show removal, seat release, reopening, cancellations, price changes, and blocked seats require flags. **Do not sum hourly as-of seat totals**; doing so repeats prior unavailable inventory. A midnight 7 November capture supplies a baseline but cannot identify how many unavailable seats were already unavailable before midnight.

**Proposed API** (`null` where unknown, never synthetic numbers in observed mode):

```json
{
  "movieId": "176276",
  "performanceDate": "2026-11-07",
  "observedAt": "2026-11-07T12:00:00+05:30",
  "timezone": "Asia/Kolkata",
  "sourceStatus": "observed_partial",
  "stateId": "<official_state_code>",
  "stateName": "West Bengal",
  "coverage": {"cityFeedsObserved": null, "cinemasObserved": null},
  "totals": {"shows": null, "totalSeats": null, "unavailableSeats": null, "weightedOccupancy": null, "listedUnavailableSeatValueINR": null},
  "lastHour": {"netUnavailable": null, "positiveUnavailable": null, "seatReleases": null, "matchedScreenings": null},
  "districts": [],
  "cities": [],
  "cinemas": []
}
```

### Geographic data ownership

- Store a **physical cinema** location and government state/district identifiers; do not equate a District ticket-booking *city feed* with the cinema's actual city, state, or district.
- A show appearing in multiple feed URLs must be counted only once in national, state, district, and city totals.
- Delhi NCR is a multi-state region in real life. The **Delhi demo entry is assigned to Delhi only as synthetic UI data**; a production collector must geocode venues and split them correctly across Delhi, Haryana and Uttar Pradesh.
- Official state/district polygon files should be pinned to a specific revision, transformed to GeoJSON once during a controlled build, visually checked, simplified where appropriate, and stored locally for production. Avoid production runtime dependency on a remote data-hosting service.
- Show northern national border only after comparison with SoI's current political map; do not fall back to an unsourced map on failure.

## Tested in this prototype

- Desktop 1440px and mobile 390px viewport; no JavaScript errors in tested navigation.
- State index has 36 states/UTs, search, state detail, city/district/cinema tabs, close button, mode switching.
- Verified West Bengal data reconciles to **117 shows, 27,663 seats, 7,202 unavailable seats, ₹39,48,610 listed unavailable-seat value**.
- An *artificial local test GeoJSON ZIP* was used solely to validate importer, SVG polygon creation, hover/click code and panel wiring. It was never included in shipped assets and is not called an official map.
- Real production SoI/NWIC geometry could **not** be downloaded in this environment. Full official boundary fidelity remains unverified until that file is imported and compared visually.
