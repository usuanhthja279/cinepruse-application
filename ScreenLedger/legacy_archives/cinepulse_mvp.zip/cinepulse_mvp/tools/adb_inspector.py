"""Generic, read-only foreground Android UI inspector.

Use with your own apps or an app for which you are authorized to collect data.
Does not navigate or automate BookMyShow and does not bypass app protections.
"""
import argparse
import os
import shutil
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path


def adb_path():
    return os.getenv('ADB_PATH') or shutil.which('adb') or str(Path.home()/'AppData'/'Local'/'Android'/'Sdk'/'platform-tools'/'adb.exe')


def run(*arguments):
    args=[adb_path(),*arguments]
    p=subprocess.run(args,check=True,capture_output=True,timeout=40)
    return p.stdout


def inspect(xml_path=None):
    if xml_path:
        blob=Path(xml_path).read_bytes()
    else:
        run('shell','uiautomator','dump','/sdcard/cinepulse-ui.xml')
        blob=run('exec-out','cat','/sdcard/cinepulse-ui.xml')
    root=ET.fromstring(blob)
    results=[]
    for node in root.iter('node'):
        attrs=node.attrib
        text=attrs.get('text','').strip()
        desc=attrs.get('content-desc','').strip()
        if text or desc:
            results.append({'text':text,'description':desc,'resource_id':attrs.get('resource-id',''),
                            'bounds':attrs.get('bounds',''),'class':attrs.get('class','')})
    return results


if __name__=='__main__':
    parser=argparse.ArgumentParser(description='Inspect visible Android UI text from authorized apps')
    parser.add_argument('--xml',help='Inspect an already exported UI hierarchy XML')
    parser.add_argument('--save',help='Save extracted text to a UTF-8 file')
    opts=parser.parse_args()
    import json
    result=json.dumps(inspect(opts.xml),ensure_ascii=False,indent=2)
    print(result)
    if opts.save:
        Path(opts.save).write_text(result,encoding='utf-8')
