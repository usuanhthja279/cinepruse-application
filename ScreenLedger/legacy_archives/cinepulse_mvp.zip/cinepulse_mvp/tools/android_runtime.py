"""Windows Android SDK runtime controller (optional).

Requires a working official Android Emulator AVD and SDK platform-tools.
No app-specific automation, security bypasses, or scraping.
"""
import argparse
import os
import shutil
import subprocess
from pathlib import Path


def paths():
    home = Path.home()
    roots = [Path(p) for p in (os.getenv('ANDROID_HOME'),os.getenv('ANDROID_SDK_ROOT'),os.getenv('LOCALAPPDATA','')+'\\Android\\Sdk','C:\\AndroidSDK') if p]
    for root in roots:
        if (root/'emulator'/'emulator.exe').exists() and (root/'platform-tools'/'adb.exe').exists():
            return str(root/'emulator'/'emulator.exe'),str(root/'platform-tools'/'adb.exe')
    emulator=shutil.which('emulator') or shutil.which('emulator.exe')
    adb=shutil.which('adb') or shutil.which('adb.exe')
    if emulator and adb:
        return emulator,adb
    raise FileNotFoundError('Android Emulator/adb not found; install SDK emulator and platform-tools, or set ANDROID_HOME.')


def run(argv,timeout=25):
    p=subprocess.run(argv,check=True,text=True,capture_output=True,timeout=timeout)
    return p.stdout.strip()


def main():
    p=argparse.ArgumentParser(description='Low-overhead official Android runtime controller')
    p.add_argument('action',choices=('doctor','list','start','stop','screenshot'))
    p.add_argument('--avd',default='MiniAndroid',help='Existing AVD name (start only)')
    p.add_argument('--serial',default='emulator-5554',help='ADB device serial (stop/screenshot)')
    p.add_argument('--output',default='android-screen.png')
    args=p.parse_args()
    emulator,adb=paths()
    if args.action=='doctor':
        print('Emulator:',emulator,'\nadb:',adb)
        print('Emulator version:',run([emulator,'-version']).splitlines()[0])
        print('Connected devices:\n'+run([adb,'devices']))
    elif args.action=='list':
        print('Available AVDs:\n'+run([emulator,'-list-avds']))
    elif args.action=='start':
        available=run([emulator,'-list-avds']).splitlines()
        if args.avd not in available:
            raise SystemExit(f'AVD {args.avd!r} not found. Use list, or create it via avdmanager.')
        logfile=Path(__file__).resolve().parent.parent/'android-runtime.log'
        out=logfile.open('ab')
        argv=[emulator,'-avd',args.avd,'-memory','2048','-cores','2',
              '-no-window','-no-audio','-no-boot-anim','-gpu','auto']
        flags=0
        if os.name=='nt':
            flags=subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP
        child=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=out,stderr=subprocess.STDOUT,
                               creationflags=flags,close_fds=True)
        out.close()
        print(f'Started background emulator PID {child.pid}. Initial boot can take time. Log: {logfile}')
        print('Check status with: python tools\\android_runtime.py doctor')
    elif args.action=='stop':
        print(run([adb,'-s',args.serial,'emu','kill']))
    elif args.action=='screenshot':
        data=subprocess.run([adb,'-s',args.serial,'exec-out','screencap','-p'],
                            check=True,capture_output=True,timeout=35).stdout
        Path(args.output).write_bytes(data)
        print('Saved:',args.output)


if __name__=='__main__':
    main()
