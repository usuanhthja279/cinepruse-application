"""CinePulse: dependency-free, localhost-only movie ticket momentum dashboard.

Data sources in MVP: demo generator and manual/authorized observations only.
No automated collection from BookMyShow is included.
"""
import csv
import io
import json
import math
import os
import random
import re
import sqlite3
import statistics
import threading
import time
import urllib.error
import urllib.request
from datetime import datetime, timedelta, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse
from zoneinfo import ZoneInfo

BASE = Path(__file__).resolve().parent
DB = Path(os.getenv("CINEPULSE_DB", str(BASE / "data" / "cinepulse.db")))
PORT = int(os.getenv("CINEPULSE_PORT", "8765"))
IST = ZoneInfo("Asia/Kolkata")
MOCK_TITLES = ["Monsoon Express", "The Last Signal", "City of Dreams", "Midnight Runway", "Final Take"]
SCHEDULER_ON = False
SCHEDULER_LOCK = threading.Lock()
SCHEDULER_NEXT = None


def connection():
    DB.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(DB, timeout=10)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("PRAGMA busy_timeout=5000")
    return con


def setup():
    with connection() as con:
        con.executescript('''
            CREATE TABLE IF NOT EXISTS movies (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE,
                watched INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS readings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                movie_id INTEGER NOT NULL REFERENCES movies(id),
                recorded_at TEXT NOT NULL,
                rolling_hour INTEGER NOT NULL CHECK(rolling_hour >= 0),
                raw_text TEXT NOT NULL,
                source TEXT NOT NULL,
                scope TEXT NOT NULL DEFAULT 'unverified',
                quality TEXT NOT NULL DEFAULT 'exact',
                UNIQUE(movie_id, recorded_at, source)
            );
            CREATE INDEX IF NOT EXISTS idx_readings_movie_time ON readings(movie_id, recorded_at DESC);
            CREATE TABLE IF NOT EXISTS post_drafts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at TEXT NOT NULL,
                movie_id INTEGER NOT NULL REFERENCES movies(id),
                body TEXT NOT NULL,
                state TEXT NOT NULL DEFAULT 'draft',
                external_id TEXT
            );
        ''')
        if not con.execute("SELECT 1 FROM movies LIMIT 1").fetchone():
            stamp = datetime.now(timezone.utc).isoformat()
            con.executemany("INSERT INTO movies(name,created_at) VALUES (?,?)", [(v,stamp) for v in MOCK_TITLES])
            now = datetime.now(timezone.utc).replace(second=0,microsecond=0)
            now = now - timedelta(minutes=now.minute%10)
            movie_ids = [r['id'] for r in con.execute("SELECT id FROM movies ORDER BY id").fetchall()]
            for ix, movie_id in enumerate(movie_ids):
                rand = random.Random(19+ix)
                buckets = []
                for n in range(90):
                    when = now - timedelta(minutes=(89-n)*10)
                    hour = when.astimezone(IST).hour
                    day_pattern = 0.45 + 0.65 * (1 + math.sin((hour-11)*math.pi/12)) / 2
                    base = (1700 - ix*240) * day_pattern
                    bucket = max(5, round(base * (0.8 + 0.4*rand.random())))
                    buckets.append(bucket)
                    if n >= 5:
                        rolling = sum(buckets[-6:])
                        con.execute('''INSERT INTO readings(movie_id, recorded_at, rolling_hour, raw_text, source, scope, quality)
                                       VALUES(?,?,?,?,?,?,?)''',
                                    (movie_id, when.isoformat(), rolling, str(rolling), 'DEMO', 'illustrative', 'exact'))


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def add_movie(name):
    name = str(name or '').strip()
    if not 2 <= len(name) <= 120:
        raise ValueError('Movie name must contain 2-120 characters')
    with connection() as con:
        con.execute("INSERT INTO movies(name,created_at) VALUES (?,?)", (name,utc_now()))
        return con.execute("SELECT id FROM movies WHERE name=?",(name,)).fetchone()['id']


def parse_count(value):
    """Parse only exact counts. K/M/plus readings are lossy: retain raw but mark rounded.

    Human input can include 12.4K or 10K+; midpoint estimate is NOT an exact count.
    """
    s = str(value or '').strip().replace(',', '')
    match = re.fullmatch(r'(\d+(?:\.\d+)?)\s*([KkMm]?)\s*(\+?)', s)
    if not match:
        raise ValueError('Count should look like 12842, 12.4K, or 10K+')
    magnitude = match.group(2).upper()
    n = float(match.group(1)) * {'':1,'K':1000,'M':1000000}[magnitude]
    if not 0 <= n <= 1e9:
        raise ValueError('Count out of supported range')
    qual = 'lower_bound' if match.group(3) else ('rounded' if magnitude else 'exact')
    return round(n), qual


def record(movie_id, text, source='MANUAL', scope='unverified', recorded_at=None):
    amount, qual = parse_count(text)
    scope = str(scope or 'unverified').strip()[:90]
    source = str(source or 'MANUAL').strip()[:24].upper()
    if source not in ('MANUAL','AUTHORIZED','DEMO','CSV'):
        raise ValueError('Unsupported source')
    if recorded_at:
        dt = datetime.fromisoformat(str(recorded_at).replace('Z','+00:00'))
        if dt.tzinfo is None:
            raise ValueError('Timestamp must include timezone')
        timestamp = dt.astimezone(timezone.utc).isoformat()
    else:
        timestamp = utc_now()
    with connection() as con:
        if not con.execute("SELECT 1 FROM movies WHERE id=?",(int(movie_id),)).fetchone():
            raise ValueError('Movie not found')
        # The first genuine observation replaces synthetic history for that title.
        # Never train a forecast on a mixture of real and simulated readings.
        if source != 'DEMO':
            con.execute('DELETE FROM readings WHERE movie_id=? AND source="DEMO"',(int(movie_id),))
        con.execute('''INSERT INTO readings(movie_id,recorded_at,rolling_hour,raw_text,source,scope,quality)
                       VALUES(?,?,?,?,?,?,?)''',(int(movie_id),timestamp,amount,str(text),source,scope,qual))
    return {'value':amount,'quality':qual,'timestamp':timestamp}


def simulate_new():
    """Demo-only: smooth evolution of a synthetic moving-hour metric."""
    with connection() as con:
        rows = con.execute("SELECT id FROM movies WHERE watched=1 ORDER BY id LIMIT 5").fetchall()
        for row in rows:
            movie_id = row['id']
            # Skip titles with any real data: synthetic and real series must stay separate.
            if con.execute('SELECT 1 FROM readings WHERE movie_id=? AND source!="DEMO" LIMIT 1',(movie_id,)).fetchone():
                continue
            prior = con.execute("SELECT rolling_hour FROM readings WHERE movie_id=? ORDER BY recorded_at DESC LIMIT 1",(movie_id,)).fetchone()
            if not prior:
                continue
            previous = int(prior['rolling_hour'])
            rng = random.Random(f"{movie_id}|{int(time.time()//600)}")
            change = round(previous*rng.uniform(-0.075,0.095))
            value = max(0,previous+change)
            record(movie_id,str(value),source='DEMO',scope='illustrative')


def forecast(rows, minutes):
    """Conservative baseline forecasting the reported rolling-hour value, not new sales."""
    if len(rows) < 3 or any(r['quality']=='lower_bound' for r in rows[-6:]):
        return None
    last = float(rows[-1]['rolling_hour'])
    diffs = [rows[i]['rolling_hour']-rows[i-1]['rolling_hour'] for i in range(1,len(rows))]
    diffs = diffs[-6:]
    weighted_slope = sum((i+1)*d for i,d in enumerate(diffs))/sum(range(1,len(diffs)+1))
    typical = statistics.median(abs(d) for d in diffs) if diffs else 0
    steps = minutes/10
    estimate = max(0,round(last + weighted_slope * steps))
    uncertainty = round((typical + 0.05 * last) * math.sqrt(steps))
    return {'minutes':minutes, 'value':estimate, 'low':max(0,estimate-uncertainty),
            'high':estimate+uncertainty, 'method':'weighted recent net-change extrapolation',
            'note':'Illustrative heuristic band, not statistically calibrated confidence interval.'}


def dashboard(movie_id=None):
    with connection() as con:
        movies = [dict(r) for r in con.execute("SELECT * FROM movies ORDER BY id")]
        for m in movies:
            latest = con.execute("SELECT * FROM readings WHERE movie_id=? ORDER BY recorded_at DESC LIMIT 1",(m['id'],)).fetchone()
            m['latest'] = dict(latest) if latest else None
        if movie_id is None and movies:
            best = max((m for m in movies if m['latest']), key=lambda m:m['latest']['rolling_hour'],default=None)
            movie_id = best['id'] if best else movies[0]['id']
        chosen = next((m for m in movies if m['id']==int(movie_id)),None)
        if not chosen:
            raise ValueError('Movie not found')
        rows = [dict(r) for r in con.execute("SELECT * FROM readings WHERE movie_id=? ORDER BY recorded_at DESC LIMIT 150",(chosen['id'],))]
        rows.reverse()
        recent = rows[-1] if rows else None
        previous = rows[-2] if len(rows)>1 else None
        delta = (recent['rolling_hour']-previous['rolling_hour']) if recent and previous else None
        preds = {str(m):forecast(rows,m) for m in (10,30,60)}
        drafts = [dict(r) for r in con.execute("SELECT * FROM post_drafts ORDER BY id DESC LIMIT 10")]
        return {'movie':chosen,'movies':movies,'readings':rows,'latest':recent,
                'previous':previous,'net_change':delta,'forecasts':preds,'drafts':drafts,
                'scheduler_on':SCHEDULER_ON,'scheduler_next':SCHEDULER_NEXT,
                'all_demo':bool(rows) and all(r['source']=='DEMO' for r in rows),
                'disclaimer':'A change between rolling-hour totals is NOT tickets booked in the last ten minutes.'}


def draft_post(movie_id):
    d=dashboard(movie_id)
    latest=d['latest']
    if not latest:
        raise ValueError('Need at least one reading')
    title=d['movie']['name']
    stamp=datetime.fromisoformat(latest['recorded_at']).astimezone(IST).strftime('%d %b, %I:%M %p IST')
    demo='🧪 DEMO / SYNTHETIC DATA — NOT REAL TICKET SALES\n' if latest['source']=='DEMO' else ''
    scope=latest['scope']
    if latest['quality']=='lower_bound':
        amount=f"at least {latest['raw_text']}"
    elif latest['quality']=='rounded':
        amount=f"about {latest['raw_text']}"
    else:
        amount=f"{latest['rolling_hour']:,}"
    momentum = f"\nRolling-hour momentum: {d['net_change']:+,} vs previous reading" if d['net_change'] is not None else ''
    body=(f"{demo}🎬 {title}\n🎟️ {amount} bookings shown for the preceding hour"
          f"\n🕒 Observed: {stamp}{momentum}\n📍 Scope: {scope}"
          f"\nSource: {latest['source']} | Rolling-hour count; not box office revenue.")
    if len(body)>280:
        body=body[:277]+'...'
    with connection() as con:
        cur=con.execute("INSERT INTO post_drafts(created_at,movie_id,body) VALUES(?,?,?)",(utc_now(),movie_id,body))
    return {'id':cur.lastrowid, 'body':body, 'state':'draft'}


def csv_export():
    with connection() as con:
        rows=con.execute('''SELECT m.name,r.recorded_at,r.rolling_hour,r.raw_text,r.source,r.scope,r.quality
                            FROM readings r JOIN movies m ON r.movie_id=m.id
                            ORDER BY r.recorded_at DESC''').fetchall()
    f=io.StringIO(newline='')
    writer=csv.writer(f)
    writer.writerow(['movie','recorded_at_utc','rolling_hour','raw_text','source','scope','quality'])
    for row in rows:
        writer.writerow(list(row))
    return f.getvalue().encode('utf-8-sig')


def import_csv(content):
    reader=csv.DictReader(io.StringIO(content))
    count=0
    with connection() as con:
        movies={r['name'].lower():r['id'] for r in con.execute('SELECT id,name FROM movies')}
    for row in reader:
        name=(row.get('movie') or '').strip()
        if not name:
            raise ValueError('CSV needs a movie column')
        mid=movies.get(name.lower())
        if not mid:
            mid=add_movie(name)
            movies[name.lower()]=mid
        record(mid,row.get('raw_text') or row.get('rolling_hour'),source='CSV',
               scope=row.get('scope') or 'unverified',recorded_at=row.get('recorded_at_utc') or None)
        count+=1
        if count>10000:
            raise ValueError('CSV import exceeds 10,000 rows')
    return count


class Handler(BaseHTTPRequestHandler):
    def json_reply(self, data, code=200):
        payload=json.dumps(data,ensure_ascii=False).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Content-Length',str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def do_GET(self):
        p=urlparse(self.path)
        try:
            if p.path in ('/','/index.html'):
                body=(BASE/'static'/'index.html').read_bytes()
                self.send_response(200)
                self.send_header('Content-Type','text/html; charset=utf-8')
                self.send_header('X-Content-Type-Options','nosniff')
                self.send_header('Content-Length',str(len(body)))
                self.end_headers(); self.wfile.write(body); return
            if p.path=='/api/dashboard':
                q=parse_qs(p.query)
                self.json_reply(dashboard(int(q['movie_id'][0]) if 'movie_id' in q else None));return
            if p.path=='/api/status':
                self.json_reply({'ok':True,'mode':'DEMO / MANUAL / AUTHORIZED',
                                 'scheduler_on':SCHEDULER_ON,'next_run':SCHEDULER_NEXT,
                                 'time':utc_now()});return
            if p.path=='/api/export.csv':
                body=csv_export()
                self.send_response(200)
                self.send_header('Content-Type','text/csv; charset=utf-8')
                self.send_header('Content-Disposition','attachment; filename="cinepulse_readings.csv"')
                self.send_header('Content-Length',str(len(body)))
                self.end_headers();self.wfile.write(body);return
            self.json_reply({'error':'Not found'},404)
        except (ValueError,sqlite3.IntegrityError) as exc:
            self.json_reply({'error':str(exc)},400)
        except Exception as exc:
            self.json_reply({'error':f'Unexpected server error: {exc}'},500)

    def do_POST(self):
        p=urlparse(self.path)
        length=int(self.headers.get('Content-Length','0'))
        if length>2*1024*1024:
            self.json_reply({'error':'Payload too large'},413);return
        try:
            raw=self.rfile.read(length)
            if p.path=='/api/import.csv':
                count=import_csv(raw.decode('utf-8-sig'))
                self.json_reply({'imported':count});return
            params=json.loads(raw or b'{}')
            if p.path=='/api/add_movie':
                movie_id=add_movie(params.get('name'))
                self.json_reply({'id':movie_id},201);return
            if p.path=='/api/record':
                out=record(params['movie_id'],params['raw_text'],params.get('source','MANUAL'),
                           params.get('scope','unverified'),params.get('recorded_at'))
                self.json_reply(out,201);return
            if p.path=='/api/simulate':
                simulate_new();self.json_reply({'ok':True,'message':'Synthetic demo reading generated.'});return
            if p.path=='/api/draft':
                draft=draft_post(int(params['movie_id']))
                self.json_reply(draft,201);return
            if p.path=='/api/scheduler':
                global SCHEDULER_ON, SCHEDULER_NEXT
                SCHEDULER_ON=bool(params.get('enabled'))
                SCHEDULER_NEXT=time.time()+600 if SCHEDULER_ON else None
                self.json_reply({'scheduler_on':SCHEDULER_ON,
                                 'note':'Scheduler produces SYNTHETIC DEMO data only; never accesses BookMyShow.'});return
            if p.path=='/api/watch':
                with connection() as con:
                    con.execute('UPDATE movies SET watched=? WHERE id=?',(int(bool(params['watched'])),int(params['movie_id'])))
                self.json_reply({'ok':True});return
            self.json_reply({'error':'Not found'},404)
        except (ValueError,KeyError,TypeError,json.JSONDecodeError,sqlite3.IntegrityError) as exc:
            self.json_reply({'error':str(exc)},400)
        except Exception as exc:
            self.json_reply({'error':f'Unexpected server error: {exc}'},500)

    def log_message(self, fmt,*args):
        print('[CinePulse]',fmt % args)


def demo_scheduler():
    global SCHEDULER_NEXT
    while True:
        if SCHEDULER_ON and SCHEDULER_NEXT and time.time()>=SCHEDULER_NEXT:
            with SCHEDULER_LOCK:
                if SCHEDULER_ON and SCHEDULER_NEXT and time.time()>=SCHEDULER_NEXT:
                    try: simulate_new()
                    except Exception as exc: print('Demo generator error:',exc)
                    SCHEDULER_NEXT=time.time()+600
        time.sleep(1)


def main():
    setup()
    threading.Thread(target=demo_scheduler,name='cinepulse-demo-scheduler',daemon=True).start()
    print(f'CinePulse running at http://127.0.0.1:{PORT}')
    print('Data sources: DEMO and manually entered/authorized data. No BMS automation.')
    ThreadingHTTPServer(('127.0.0.1',PORT),Handler).serve_forever()


if __name__=='__main__':
    main()
