import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import app

class TestCinePulse(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.patch=patch.object(app,'DB',Path(self.temp.name)/'db.sqlite3')
        self.patch.start()
        app.setup()

    def tearDown(self):
        self.patch.stop()
        self.temp.cleanup()

    def test_seed_and_forecast(self):
        d=app.dashboard()
        self.assertEqual(5,len(d['movies']))
        self.assertTrue(d['all_demo'])
        self.assertIsNotNone(d['forecasts']['10'])

    def test_count_types(self):
        self.assertEqual((12000,'rounded'),app.parse_count('12K'))
        self.assertEqual((12500,'lower_bound'),app.parse_count('12.5K+'))
        self.assertEqual((12345,'exact'),app.parse_count('12,345'))
        with self.assertRaises(ValueError):
            app.parse_count('99 bananas')

    def test_demo_not_mixed_with_manual(self):
        mid=app.dashboard()['movie']['id']
        app.record(mid,'12345',source='MANUAL')
        with app.connection() as con:
            self.assertEqual(0,con.execute('SELECT count(*) AS n FROM readings WHERE movie_id=? AND source="DEMO"',(mid,)).fetchone()['n'])
        app.simulate_new()
        with app.connection() as con:
            self.assertEqual(1,con.execute('SELECT count(*) AS n FROM readings WHERE movie_id=?',(mid,)).fetchone()['n'])

    def test_net_change_not_new_sales(self):
        self.assertEqual(2000,12000-10000)
        self.assertEqual(12000,10000-3000+5000)
        self.assertNotEqual(2000,5000)

    def test_record_and_draft(self):
        mid=app.add_movie('Test Film')
        app.record(mid,'1.2K',scope='India')
        d=app.dashboard(mid)
        self.assertEqual(1200,d['latest']['rolling_hour'])
        self.assertEqual('rounded',d['latest']['quality'])
        post=app.draft_post(mid)
        self.assertIn('bookings shown for the preceding hour',post['body'])
        self.assertLessEqual(len(post['body']),280)

if __name__=='__main__':unittest.main()
