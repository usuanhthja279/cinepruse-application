# CinePulse MVP — Local-first movie ticket momentum dashboard

**Status:** Working local prototype with synthetic demonstration data, manual / authorized-data ingestion, SQLite, forecast baselines, CSV import/export, X post drafting, and a read-only Android UI inspector. **Not** a running BookMyShow extractor or an X auto-publisher.

## Requirements

- Windows 10/11; Python 3.10+ (Python 3.12 works); no `pip install`, Docker, Java, npm, Android Studio, or database server required for the dashboard.
- Optional: Android SDK Platform Tools (`adb`) and an Android device/emulator for generic UI inspection.
- All services bind to localhost `127.0.0.1`.

## Run (PowerShell)

```powershell
cd path\to\cinepulse_mvp
py -3 app.py
```

Open **http://127.0.0.1:8765** in your browser. Exit with Ctrl+C.

Double-click `start_windows.bat` if you prefer. The first run creates `data/cinepulse.db` and populates five clearly fictional movie titles with deterministic **DEMO** time-series observations. They are not actual box-office or BookMyShow results.

## What currently works

1. Select a movie and see a responsive dashboard chart of the last 30 rolling-hour observations.
2. Rank tracked movies by latest displayed 60-minute ticket count.
3. Calculate the **net change** between observations and forecast the **rolling-hour count** in 10, 30, or 60 minutes. Baseline is short-window weighted differences with an uncalibrated heuristic spread, not an ML model or a reliable uncertainty estimate.
4. Start or stop an opt-in 10-minute scheduler. **It adds synthetic demo data only**, never opens a third-party app.
5. Add movies, enter readings manually in `12345`, `12.4K`, or `10K+` format, and preserve original text, observed time, source, scope and precision quality.
6. Import observations from CSV, export all readings to CSV.
7. Generate and copy X post drafts. They are never published automatically. Drafts from synthetic data are explicitly prefixed with an alert.
8. Inspect text/description of the foreground Android app via an optional read-only ADB inspection tool.

## Observations CSV

Use this header (records use ISO 8601 UTC timestamps):

```csv
movie,recorded_at_utc,rolling_hour,raw_text,source,scope,quality
Example Film,2026-11-05T12:00:00+00:00,12000,12K,MANUAL,unverified,rounded
Example Film,2026-11-05T12:10:00+00:00,12500,12.5K,MANUAL,unverified,rounded
```

CSV import treats `raw_text` as canonical and marks ingested records with source `CSV`. Import an exact integer where precision matters. For rounded values, the app stores a numeric approximation **and** the raw text/quality; never label these as exact.

## Lightweight Android emulator controller (optional)

If you have an existing Android SDK install containing emulator.exe and adb.exe, and an AVD
already created (e.g. named `MiniAndroid`), the optional controller lets you run it
**headlessly**, without the entire Android Studio desktop UI:

```powershell
py -3 tools\android_runtime.py doctor
py -3 tools\android_runtime.py list
py -3 tools\android_runtime.py start --avd MiniAndroid
py -3 tools\android_runtime.py screenshot --output screen.png
py -3 tools\android_runtime.py stop
```

The launcher asks for 2 GB Android guest memory and 2 virtual CPU cores. These are
not guarantees for total host RAM usage, which can be higher. Keep the emulator
running and idle between samples rather than repeatedly booting it every 10 minutes.
The AVD must be prepared separately through the Android SDK or Android Studio.
This build does **not** bundle Android, Android Studio, Google Play system images or
BookMyShow; those are obtained from their respective publishers.

## Android UI inspector (optional)

With `adb` on PATH, or set `ADB_PATH` to the exact adb.exe location:

```powershell
py -3 tools\adb_inspector.py --save visible-ui.json
```

This inspects the *current* Android foreground app's accessible UI text and content descriptions. It does not launch apps, perform automatic clicks, circumvent protections, scrape BookMyShow, or collect screenshots. Use only for apps and data you are permitted to inspect. If the content is rendered into a canvas or image, accessible text can be absent and an authorized screenshot/OCR fallback may be required later.

Test against an exported XML locally without a connected Android device:

```powershell
py -3 tools\adb_inspector.py --xml test-ui.xml
```

## Intended adapter design (not implemented)

Future authenticated/authorized source adapters should implement this conceptual contract:

```python
Observation(
    movie_id=123,
    timestamp_utc="2026-11-05T12:00:00+00:00",
    raw_text="12.4K",
    source="AUTHORIZED",
    scope="India (verified from source UI)",
)
```

For each ten-minute cycle, an approved adapter would: (a) refresh its authorized data source, (b) read the requested 5 tracked movie IDs sequentially, (c) validate the "last 60 minutes" label and scope, (d) store timestamps per movie, (e) retry conservatively on failure without fabricating missing observations. Set a lower collection frequency if the data provider does not permit ten-minute polling.

**BookMyShow access** requires confirming permission / a licensed data feed before shipping continuous automated extraction. Their published terms restrict scraping without express written permission. Do not bypass app login, captchas, anti-automation controls, access restrictions or rate limits. The code ships without a BookMyShow integration for this reason.

## Interpretation: rolling one-hour snapshots

If displayed counts are R(6:00)=10K and R(6:10)=12K, the 2K difference represents **net change in the rolling 60-minute window**. It does not mean exactly 2K new tickets were booked. New 6:00–6:10 bookings **minus** dropped 5:00–5:10 bookings = +2K. A model cannot reconstruct exact ten-minute sales from the rolling hourly counts alone without additional assumptions or measurements.

BookMyShow may round, lag, change geographic scope or vary which tickets are counted. Store the raw string, scope, sample timestamp, source, quality, and data provenance. This MVP does not estimate actual daily ticket sales or gross collections from the rolling series.

## Next steps to production

1. Validate the source presentation and scope (India-wide vs city, rolling update granularity, raw precision) with legitimate access, and arrange permission or alternative licensed data.
2. Build an `AuthorizedProvider` that returns readings for a set of watched movie IDs; include dry-run and integration tests.
3. Add read failures, sample-gap indicators, source drift and adapter health monitors.
4. Train a better forecasting model on at least 2–4 weeks of data, back-test against seasonal baselines, and calibrate interval coverage.
5. Add scheduled, deduplicated and approved X publishing via user-authorized X API; do not post synthetic data without an unmistakable label. Add budgets and a daily cap.
6. Replace local single-process scheduling with a restart-persistent job runner if running unattended.

## Tests

```powershell
py -3 -m unittest discover -s tests -v
```

## Local security notes

This is a single-user localhost prototype; there is no login or multi-user API authorization. Don't expose port 8765 to the Internet. CSV import should be used with small, trusted files only. No automated X publishing is supported. The DB is local at `data/cinepulse.db`; backup that file together with the `-wal` file after stopping the app.
